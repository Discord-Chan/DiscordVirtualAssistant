# DiscordVirtualAssistant
### by Romeo Bhuiyan
A Discord-Bot that helps you out on your server and provides some new command to have a little more fun among your friends
<br>

## Installation (self set up)
Install all npm files
```
npm i
```
Run the bot
```
npm run dev
```

## Public use
This bot is available for any server with that invite link [IN PROGRESS]
